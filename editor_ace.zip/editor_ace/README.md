Add to bower.json dependencies:
"ace": "ajaxorg/ace-builds"

Do bower install, then rename this folder to "editor".